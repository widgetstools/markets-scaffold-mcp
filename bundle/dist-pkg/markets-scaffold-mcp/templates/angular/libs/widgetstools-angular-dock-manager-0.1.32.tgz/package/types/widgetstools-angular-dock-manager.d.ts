import * as i0 from '@angular/core';
import { AfterViewInit, OnDestroy, OnChanges, Type, EventEmitter, ElementRef, ChangeDetectorRef, ApplicationRef, EnvironmentInjector, SimpleChanges } from '@angular/core';
import { PanelApi, IDisposable, DockManagerState, DockTheme, DockviewApi, PreventableDockEvent, DockPosition, DockAction, DockviewComponent } from '@widgetstools/dock-manager-core';
export { AddPanelOptions, DockAction, DockEdge, DockManagerState, DockPosition, DockTheme, DockThemeColors, DockviewApi, DockviewComponent, DockviewComponentOptions, EventEmitter, FloatPanelOptions, FloatingPanel, HeaderPosition, IDisposable, LayoutNode, MovePanelOptions, PanelConfig, PopoutPanel, PreventableDockEvent, SplitDirection, SplitNode, TabGroupNode, UnpinnedPanel, clearLocalStorage, createDefaultState, createTheme, deserialize, dockReducer, draculaDark, exportToFile, findAllTabGroups, findFirstTabGroup, findTabGroupById, findTabGroupForPanel, forestDark, getThemeByName, getThemesByMode, githubLight, importFromFile, lavenderLight, loadFromLocalStorage, midnightDark, mintLight, nordDark, saveToLocalStorage, sepiaLight, serialize, slateDark, solarizedDark, solarizedLight, themes, validateState, vsCodeDark, vsCodeLight, warmLight } from '@widgetstools/dock-manager-core';
import { Observable } from 'rxjs';

/**
 * Thin Angular wrapper around the core DockviewComponent.
 *
 * All DOM rendering, event handling, and layout logic lives in core.
 * Angular only provides panel content via dynamic component creation.
 *
 * Zoneless: Uses ChangeDetectorRef.markForCheck() instead of NgZone.
 * Compatible with both zone.js and zoneless (provideZonelessChangeDetection).
 */

/**
 * Content renderer function type.
 * Called by the core when a panel needs content.
 * @param api - PanelApi instance for widget-to-header communication.
 * Returns a dispose function to clean up when the panel is hidden/removed.
 */
type ContentRenderer = (panelId: string, container: HTMLElement, api: PanelApi) => IDisposable;
type TabRenderer = (panelId: string, container: HTMLElement, isActive: boolean) => IDisposable;
type HeaderActionsRenderer = (slot: 'left' | 'right' | 'prefix', tabGroupId: string, container: HTMLElement) => IDisposable;
type WatermarkRenderer = (container: HTMLElement) => IDisposable;
declare class DockManagerCoreComponent implements AfterViewInit, OnDestroy, OnChanges {
    private cdr;
    private appRef;
    private envInjector;
    /** Initial state for the dock manager */
    initialState: DockManagerState;
    /**
     * Widget registry: maps panel.widgetType strings to Angular component classes.
     * When provided, panels are automatically rendered using createComponent().
     * Each widget component should accept `api` and `panel` inputs.
     */
    widgets?: Record<string, Type<any>>;
    /** Content renderer — called when a panel needs content mounted into a container.
     *  Used as fallback when `widgets` registry doesn't match the panel's widgetType. */
    createContent?: ContentRenderer;
    /** Optional custom tab renderer */
    createTab?: TabRenderer;
    /** Optional header actions renderer */
    createHeaderActions?: HeaderActionsRenderer;
    /** Optional watermark renderer for empty tab groups */
    createWatermark?: WatermarkRenderer;
    /** Theme: 'light', 'dark', or a DockTheme object */
    theme: 'light' | 'dark' | DockTheme;
    /** Whether to show edge dock indicators. Defaults to true. */
    allowRootDock?: boolean;
    /** Emits when the dock manager is initialized with the DockviewApi for programmatic control */
    ready: EventEmitter<DockviewApi>;
    /** Emits when state changes */
    stateChange: EventEmitter<DockManagerState>;
    /** Emits before a panel close (preventable) */
    willClose: EventEmitter<{
        event: PreventableDockEvent;
        panelId: string;
    }>;
    /** Emits before a drop (preventable) */
    willDrop: EventEmitter<{
        event: PreventableDockEvent;
        sourceId: string;
        targetId: string;
        position: DockPosition;
    }>;
    containerRef: ElementRef<HTMLDivElement>;
    private dock;
    constructor(cdr: ChangeDetectorRef, appRef: ApplicationRef, envInjector: EnvironmentInjector);
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    /** Dispatch an action to the dock manager */
    dispatch(action: DockAction): void;
    /** Get current state */
    getState(): DockManagerState | null;
    /** Get the underlying DockviewComponent instance */
    getInstance(): DockviewComponent | null;
    /** Get the DockviewApi for programmatic control */
    getApi(): DockviewApi | null;
    /** Mount an Angular component into a container element */
    private mountComponent;
    static ɵfac: i0.ɵɵFactoryDeclaration<DockManagerCoreComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DockManagerCoreComponent, "dock-manager-core", never, { "initialState": { "alias": "initialState"; "required": false; }; "widgets": { "alias": "widgets"; "required": false; }; "createContent": { "alias": "createContent"; "required": false; }; "createTab": { "alias": "createTab"; "required": false; }; "createHeaderActions": { "alias": "createHeaderActions"; "required": false; }; "createWatermark": { "alias": "createWatermark"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "allowRootDock": { "alias": "allowRootDock"; "required": false; }; }, { "ready": "ready"; "stateChange": "stateChange"; "willClose": "willClose"; "willDrop": "willDrop"; }, never, never, true, never>;
}

type ThemeMode = 'light' | 'dark' | 'system';
declare class DockThemeService {
    private themeModeSubject;
    private mediaQueryList;
    private mediaQueryListener;
    themeMode$: Observable<ThemeMode>;
    constructor();
    setThemeMode(mode: ThemeMode): void;
    getThemeMode(): ThemeMode;
    private applyTheme;
    private isSystemDark;
    private initializeSystemModeListener;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DockThemeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DockThemeService>;
}

export { DockManagerCoreComponent, DockThemeService };
export type { ContentRenderer, HeaderActionsRenderer, TabRenderer, ThemeMode, WatermarkRenderer };
