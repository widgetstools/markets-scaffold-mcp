import { isPlatformBrowser } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, input, computed, effect, booleanAttribute, numberAttribute, Input, Directive, NgModule } from '@angular/core';
import { uuid, hasClass, createElement, appendChild, fadeIn, getWindowScrollLeft, getWindowScrollTop, findSingle, getOuterWidth, getOuterHeight, getViewport, removeChild } from '@primeuix/utils';
import { BaseComponent, PARENT_INSTANCE } from 'primeng/basecomponent';
import { BindModule } from 'primeng/bind';
import { ConnectedOverlayScrollHandler } from 'primeng/dom';
import { ZIndexUtils } from 'primeng/utils';
import { style } from '@primeuix/styles/tooltip';
import { BaseStyle } from 'primeng/base';

const classes = {
    root: 'p-tooltip p-component',
    arrow: 'p-tooltip-arrow',
    text: 'p-tooltip-text'
};
class TooltipStyle extends BaseStyle {
    name = 'tooltip';
    style = style;
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: TooltipStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: TooltipStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: TooltipStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * Tooltip directive provides advisory information for a component.
 *
 * [Live Demo](https://www.primeng.org/tooltip)
 *
 * @module tooltipstyle
 *
 */
var TooltipClasses;
(function (TooltipClasses) {
    /**
     * Class name of the root element
     */
    TooltipClasses["root"] = "p-tooltip";
    /**
     * Class name of the arrow element
     */
    TooltipClasses["arrow"] = "p-tooltip-arrow";
    /**
     * Class name of the text element
     */
    TooltipClasses["text"] = "p-tooltip-text";
})(TooltipClasses || (TooltipClasses = {}));

const TOOLTIP_INSTANCE = new InjectionToken('TOOLTIP_INSTANCE');
/**
 * Tooltip directive provides advisory information for a component.
 * @group Components
 */
class Tooltip extends BaseComponent {
    zone;
    viewContainer;
    componentName = 'Tooltip';
    $pcTooltip = inject(TOOLTIP_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    /**
     * Position of the tooltip.
     * @group Props
     */
    tooltipPosition;
    /**
     * Event to show the tooltip.
     * @group Props
     */
    tooltipEvent = 'hover';
    /**
     * Type of CSS position.
     * @group Props
     */
    positionStyle;
    /**
     * Style class of the tooltip.
     * @group Props
     */
    tooltipStyleClass;
    /**
     * Whether the z-index should be managed automatically to always go on top or have a fixed value.
     * @group Props
     */
    tooltipZIndex;
    /**
     * By default the tooltip contents are rendered as text. Set to false to support html tags in the content.
     * @group Props
     */
    escape = true;
    /**
     * Delay to show the tooltip in milliseconds.
     * @group Props
     */
    showDelay;
    /**
     * Delay to hide the tooltip in milliseconds.
     * @group Props
     */
    hideDelay;
    /**
     * Time to wait in milliseconds to hide the tooltip even it is active.
     * @group Props
     */
    life;
    /**
     * Specifies the additional vertical offset of the tooltip from its default position.
     * @group Props
     */
    positionTop;
    /**
     * Specifies the additional horizontal offset of the tooltip from its default position.
     * @group Props
     */
    positionLeft;
    /**
     * Whether to hide tooltip when hovering over tooltip content.
     * @group Props
     */
    autoHide = true;
    /**
     * Automatically adjusts the element position when there is not enough space on the selected position.
     * @group Props
     */
    fitContent = true;
    /**
     * Whether to hide tooltip on escape key press.
     * @group Props
     */
    hideOnEscape = true;
    /**
     * Whether to show the tooltip only when the target text overflows (e.g., ellipsis is active).
     * @group Props
     */
    showOnEllipsis = false;
    /**
     * Content of the tooltip.
     * @group Props
     */
    content;
    /**
     * When present, it specifies that the component should be disabled.
     * @defaultValue false
     * @group Props
     */
    get disabled() {
        return this._disabled;
    }
    set disabled(val) {
        this._disabled = val;
        this.deactivate();
    }
    /**
     * Specifies the tooltip configuration options for the component.
     * @group Props
     */
    tooltipOptions;
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo = input(undefined, ...(ngDevMode ? [{ debugName: "appendTo" }] : []));
    $appendTo = computed(() => this.appendTo() || this.config.overlayAppendTo(), ...(ngDevMode ? [{ debugName: "$appendTo" }] : []));
    _tooltipOptions = {
        tooltipLabel: null,
        tooltipPosition: 'right',
        tooltipEvent: 'hover',
        appendTo: 'body',
        positionStyle: null,
        tooltipStyleClass: null,
        tooltipZIndex: 'auto',
        escape: true,
        disabled: null,
        showDelay: null,
        hideDelay: null,
        positionTop: null,
        positionLeft: null,
        life: null,
        autoHide: true,
        hideOnEscape: true,
        showOnEllipsis: false,
        id: uuid('pn_id_') + '_tooltip'
    };
    _disabled;
    container;
    styleClass;
    tooltipText;
    rootPTClasses = '';
    showTimeout;
    hideTimeout;
    active;
    mouseEnterListener;
    mouseLeaveListener;
    containerMouseleaveListener;
    clickListener;
    focusListener;
    blurListener;
    touchStartListener;
    touchEndListener;
    documentTouchListener;
    documentEscapeListener;
    scrollHandler;
    resizeListener;
    _componentStyle = inject(TooltipStyle);
    interactionInProgress = false;
    /**
     * Used to pass attributes to DOM elements inside the Tooltip component.
     * @defaultValue undefined
     * @deprecated use pTooltipPT instead.
     * @group Props
     */
    ptTooltip = input(...(ngDevMode ? [undefined, { debugName: "ptTooltip" }] : []));
    /**
     * Used to pass attributes to DOM elements inside the Tooltip component.
     * @defaultValue undefined
     * @group Props
     */
    pTooltipPT = input(...(ngDevMode ? [undefined, { debugName: "pTooltipPT" }] : []));
    /**
     * Indicates whether the component should be rendered without styles.
     * @defaultValue undefined
     * @group Props
     */
    pTooltipUnstyled = input(...(ngDevMode ? [undefined, { debugName: "pTooltipUnstyled" }] : []));
    constructor(zone, viewContainer) {
        super();
        this.zone = zone;
        this.viewContainer = viewContainer;
        effect(() => {
            const pt = this.ptTooltip() || this.pTooltipPT();
            pt && this.directivePT.set(pt);
        });
        effect(() => {
            this.pTooltipUnstyled() && this.directiveUnstyled.set(this.pTooltipUnstyled());
        });
    }
    onAfterViewInit() {
        if (isPlatformBrowser(this.platformId)) {
            this.zone.runOutsideAngular(() => {
                const tooltipEvent = this.getOption('tooltipEvent');
                if (tooltipEvent === 'hover' || tooltipEvent === 'both') {
                    this.mouseEnterListener = this.onMouseEnter.bind(this);
                    this.mouseLeaveListener = this.onMouseLeave.bind(this);
                    this.clickListener = this.onInputClick.bind(this);
                    this.el.nativeElement.addEventListener('mouseenter', this.mouseEnterListener);
                    this.el.nativeElement.addEventListener('click', this.clickListener);
                    this.el.nativeElement.addEventListener('mouseleave', this.mouseLeaveListener);
                    // Touch support
                    this.touchStartListener = this.onTouchStart.bind(this);
                    this.touchEndListener = this.onTouchEnd.bind(this);
                    this.el.nativeElement.addEventListener('touchstart', this.touchStartListener, { passive: true });
                    this.el.nativeElement.addEventListener('touchend', this.touchEndListener, { passive: true });
                }
                if (tooltipEvent === 'focus' || tooltipEvent === 'both') {
                    this.focusListener = this.onFocus.bind(this);
                    this.blurListener = this.onBlur.bind(this);
                    let target = this.el.nativeElement.querySelector('.p-component');
                    if (!target) {
                        target = this.getTarget(this.el.nativeElement);
                    }
                    target.addEventListener('focus', this.focusListener);
                    target.addEventListener('blur', this.blurListener);
                }
            });
        }
    }
    onChanges(simpleChange) {
        if (simpleChange.tooltipPosition) {
            this.setOption({ tooltipPosition: simpleChange.tooltipPosition.currentValue });
        }
        if (simpleChange.tooltipEvent) {
            this.setOption({ tooltipEvent: simpleChange.tooltipEvent.currentValue });
        }
        if (simpleChange.appendTo) {
            this.setOption({ appendTo: simpleChange.appendTo.currentValue });
        }
        if (simpleChange.positionStyle) {
            this.setOption({ positionStyle: simpleChange.positionStyle.currentValue });
        }
        if (simpleChange.tooltipStyleClass) {
            this.setOption({ tooltipStyleClass: simpleChange.tooltipStyleClass.currentValue });
        }
        if (simpleChange.tooltipZIndex) {
            this.setOption({ tooltipZIndex: simpleChange.tooltipZIndex.currentValue });
        }
        if (simpleChange.escape) {
            this.setOption({ escape: simpleChange.escape.currentValue });
        }
        if (simpleChange.showDelay) {
            this.setOption({ showDelay: simpleChange.showDelay.currentValue });
        }
        if (simpleChange.hideDelay) {
            this.setOption({ hideDelay: simpleChange.hideDelay.currentValue });
        }
        if (simpleChange.life) {
            this.setOption({ life: simpleChange.life.currentValue });
        }
        if (simpleChange.positionTop) {
            this.setOption({ positionTop: simpleChange.positionTop.currentValue });
        }
        if (simpleChange.positionLeft) {
            this.setOption({ positionLeft: simpleChange.positionLeft.currentValue });
        }
        if (simpleChange.disabled) {
            this.setOption({ disabled: simpleChange.disabled.currentValue });
        }
        if (simpleChange.content) {
            this.setOption({ tooltipLabel: simpleChange.content.currentValue });
            if (this.active) {
                if (simpleChange.content.currentValue) {
                    if (this.container && this.container.offsetParent) {
                        this.updateText();
                        this.align();
                    }
                    else {
                        this.show();
                    }
                }
                else {
                    this.hide();
                }
            }
        }
        if (simpleChange.autoHide) {
            this.setOption({ autoHide: simpleChange.autoHide.currentValue });
        }
        if (simpleChange.showOnEllipsis) {
            this.setOption({ showOnEllipsis: simpleChange.showOnEllipsis.currentValue });
        }
        if (simpleChange.id) {
            this.setOption({ id: simpleChange.id.currentValue });
        }
        if (simpleChange.tooltipOptions) {
            this._tooltipOptions = { ...this._tooltipOptions, ...simpleChange.tooltipOptions.currentValue };
            this.deactivate();
            if (this.active) {
                if (this.getOption('tooltipLabel')) {
                    if (this.container && this.container.offsetParent) {
                        this.updateText();
                        this.align();
                    }
                    else {
                        this.show();
                    }
                }
                else {
                    this.hide();
                }
            }
        }
    }
    isAutoHide() {
        return this.getOption('autoHide');
    }
    onMouseEnter(e) {
        if (!this.container && !this.showTimeout) {
            this.activate();
        }
    }
    onMouseLeave(e) {
        if (!this.isAutoHide()) {
            const valid = hasClass(e.relatedTarget, 'p-tooltip') || hasClass(e.relatedTarget, 'p-tooltip-text') || hasClass(e.relatedTarget, 'p-tooltip-arrow');
            !valid && this.deactivate();
        }
        else {
            this.deactivate();
        }
    }
    onTouchStart(e) {
        if (!this.container && !this.showTimeout) {
            this.activate();
            if (!this.isAutoHide()) {
                this.bindDocumentTouchListener();
            }
        }
    }
    onTouchEnd(e) {
        if (this.isAutoHide()) {
            this.deactivate();
        }
    }
    bindDocumentTouchListener() {
        if (!this.documentTouchListener) {
            this.documentTouchListener = this.renderer.listen('document', 'touchstart', (e) => {
                if (this.container && !this.container.contains(e.target) && !this.el.nativeElement.contains(e.target)) {
                    this.deactivate();
                    this.unbindDocumentTouchListener();
                }
            });
        }
    }
    unbindDocumentTouchListener() {
        if (this.documentTouchListener) {
            this.documentTouchListener();
            this.documentTouchListener = null;
        }
    }
    onFocus(e) {
        this.activate();
    }
    onBlur(e) {
        this.deactivate();
    }
    onInputClick(e) {
        this.deactivate();
    }
    hasEllipsis() {
        const el = this.el.nativeElement;
        return el.offsetWidth < el.scrollWidth || el.offsetHeight < el.scrollHeight;
    }
    activate() {
        if (!this.interactionInProgress) {
            if (this.getOption('showOnEllipsis') && !this.hasEllipsis()) {
                return;
            }
            this.active = true;
            this.clearHideTimeout();
            if (this.getOption('showDelay'))
                this.showTimeout = setTimeout(() => {
                    this.show();
                }, this.getOption('showDelay'));
            else
                this.show();
            if (this.getOption('life')) {
                let duration = this.getOption('showDelay') ? this.getOption('life') + this.getOption('showDelay') : this.getOption('life');
                this.hideTimeout = setTimeout(() => {
                    this.hide();
                }, duration);
            }
            if (this.getOption('hideOnEscape')) {
                this.documentEscapeListener = this.renderer.listen('document', 'keydown.escape', () => {
                    this.deactivate();
                    this.documentEscapeListener?.();
                });
            }
            this.interactionInProgress = true;
        }
    }
    deactivate() {
        this.interactionInProgress = false;
        this.active = false;
        this.clearShowTimeout();
        if (this.getOption('hideDelay')) {
            this.clearHideTimeout(); //life timeout
            this.hideTimeout = setTimeout(() => {
                this.hide();
            }, this.getOption('hideDelay'));
        }
        else {
            this.hide();
        }
        if (this.documentEscapeListener) {
            this.documentEscapeListener();
        }
    }
    create() {
        if (this.container) {
            this.clearHideTimeout();
            this.remove();
        }
        this.container = createElement('div', { class: this.cx('root'), 'p-bind': this.ptm('root'), 'data-pc-section': 'root' });
        this.container.setAttribute('role', 'tooltip');
        let tooltipArrow = createElement('div', { class: this.cx('arrow'), 'p-bind': this.ptm('arrow'), 'data-pc-section': 'arrow' });
        this.container.appendChild(tooltipArrow);
        this.tooltipText = createElement('div', { class: this.cx('text'), 'p-bind': this.ptm('text'), 'data-pc-section': 'text' });
        this.updateText();
        if (this.getOption('positionStyle')) {
            this.container.style.position = this.getOption('positionStyle');
        }
        this.container.appendChild(this.tooltipText);
        if (this.getOption('appendTo') === 'body')
            document.body.appendChild(this.container);
        else if (this.getOption('appendTo') === 'target')
            appendChild(this.container, this.el.nativeElement);
        else
            appendChild(this.getOption('appendTo'), this.container);
        this.container.style.display = 'none';
        if (this.fitContent) {
            this.container.style.width = 'fit-content';
        }
        if (this.isAutoHide()) {
            this.container.style.pointerEvents = 'none';
        }
        else {
            this.container.style.pointerEvents = 'unset';
            this.bindContainerMouseleaveListener();
        }
    }
    bindContainerMouseleaveListener() {
        if (!this.containerMouseleaveListener) {
            const targetEl = this.container ?? this.container.nativeElement;
            this.containerMouseleaveListener = this.renderer.listen(targetEl, 'mouseleave', (e) => {
                this.deactivate();
            });
        }
    }
    unbindContainerMouseleaveListener() {
        if (this.containerMouseleaveListener) {
            this.bindContainerMouseleaveListener();
            this.containerMouseleaveListener = null;
        }
    }
    show() {
        if (!this.getOption('tooltipLabel') || this.getOption('disabled')) {
            return;
        }
        this.create();
        const nativeElement = this.el.nativeElement;
        const pDialogWrapper = nativeElement.closest('p-dialog');
        if (pDialogWrapper) {
            setTimeout(() => {
                this.container && (this.container.style.display = 'inline-block');
                this.container && this.align();
            }, 100);
        }
        else {
            this.container.style.display = 'inline-block';
            this.align();
        }
        fadeIn(this.container, 250);
        if (this.getOption('tooltipZIndex') === 'auto')
            ZIndexUtils.set('tooltip', this.container, this.config.zIndex.tooltip);
        else
            this.container.style.zIndex = this.getOption('tooltipZIndex');
        this.bindDocumentResizeListener();
        this.bindScrollListener();
    }
    hide() {
        if (this.getOption('tooltipZIndex') === 'auto') {
            ZIndexUtils.clear(this.container);
        }
        this.remove();
    }
    updateText() {
        const content = this.getOption('tooltipLabel');
        if (content && typeof content.createEmbeddedView === 'function') {
            const embeddedViewRef = this.viewContainer.createEmbeddedView(content);
            embeddedViewRef.detectChanges();
            embeddedViewRef.rootNodes.forEach((node) => this.tooltipText.appendChild(node));
        }
        else if (this.getOption('escape')) {
            this.tooltipText.innerHTML = '';
            this.tooltipText.appendChild(document.createTextNode(content));
        }
        else {
            this.tooltipText.innerHTML = content;
        }
    }
    align() {
        const position = this.getOption('tooltipPosition');
        const positionPriority = {
            top: [this.alignTop, this.alignBottom, this.alignRight, this.alignLeft],
            bottom: [this.alignBottom, this.alignTop, this.alignRight, this.alignLeft],
            left: [this.alignLeft, this.alignRight, this.alignTop, this.alignBottom],
            right: [this.alignRight, this.alignLeft, this.alignTop, this.alignBottom]
        };
        const alignFns = positionPriority[position] || [];
        for (let [index, alignmentFn] of alignFns.entries()) {
            if (index === 0)
                alignmentFn.call(this);
            else if (this.isOutOfBounds())
                alignmentFn.call(this);
            else
                break;
        }
    }
    getHostOffset() {
        if (this.getOption('appendTo') === 'body' || this.getOption('appendTo') === 'target') {
            let offset = this.el.nativeElement.getBoundingClientRect();
            let targetLeft = offset.left + getWindowScrollLeft();
            let targetTop = offset.top + getWindowScrollTop();
            return { left: targetLeft, top: targetTop };
        }
        else {
            return { left: 0, top: 0 };
        }
    }
    get activeElement() {
        return this.el.nativeElement.nodeName.startsWith('P-') ? findSingle(this.el.nativeElement, '.p-component') : this.el.nativeElement;
    }
    alignRight() {
        this.preAlign('right');
        const el = this.activeElement;
        const offsetLeft = getOuterWidth(el);
        const offsetTop = (getOuterHeight(el) - getOuterHeight(this.container)) / 2;
        this.alignTooltip(offsetLeft, offsetTop);
        let arrowElement = this.getArrowElement();
        arrowElement.style.top = '50%';
        arrowElement.style.right = null;
        arrowElement.style.bottom = null;
        arrowElement.style.left = '0';
    }
    alignLeft() {
        this.preAlign('left');
        let arrowElement = this.getArrowElement();
        let offsetLeft = getOuterWidth(this.container);
        let offsetTop = (getOuterHeight(this.el.nativeElement) - getOuterHeight(this.container)) / 2;
        this.alignTooltip(-offsetLeft, offsetTop);
        arrowElement.style.top = '50%';
        arrowElement.style.right = '0';
        arrowElement.style.bottom = null;
        arrowElement.style.left = null;
    }
    alignTop() {
        this.preAlign('top');
        let arrowElement = this.getArrowElement();
        let hostOffset = this.getHostOffset();
        let elementWidth = getOuterWidth(this.container);
        let offsetLeft = (getOuterWidth(this.el.nativeElement) - getOuterWidth(this.container)) / 2;
        let offsetTop = getOuterHeight(this.container);
        this.alignTooltip(offsetLeft, -offsetTop);
        let elementRelativeCenter = hostOffset.left - this.getHostOffset().left + elementWidth / 2;
        arrowElement.style.top = null;
        arrowElement.style.right = null;
        arrowElement.style.bottom = '0';
        arrowElement.style.left = elementRelativeCenter + 'px';
    }
    getArrowElement() {
        return findSingle(this.container, '[data-pc-section="arrow"]');
    }
    alignBottom() {
        this.preAlign('bottom');
        let arrowElement = this.getArrowElement();
        let elementWidth = getOuterWidth(this.container);
        let hostOffset = this.getHostOffset();
        let offsetLeft = (getOuterWidth(this.el.nativeElement) - getOuterWidth(this.container)) / 2;
        let offsetTop = getOuterHeight(this.el.nativeElement);
        this.alignTooltip(offsetLeft, offsetTop);
        let elementRelativeCenter = hostOffset.left - this.getHostOffset().left + elementWidth / 2;
        arrowElement.style.top = '0';
        arrowElement.style.right = null;
        arrowElement.style.bottom = null;
        arrowElement.style.left = elementRelativeCenter + 'px';
    }
    alignTooltip(offsetLeft, offsetTop) {
        let hostOffset = this.getHostOffset();
        let left = hostOffset.left + offsetLeft;
        let top = hostOffset.top + offsetTop;
        this.container.style.left = left + this.getOption('positionLeft') + 'px';
        this.container.style.top = top + this.getOption('positionTop') + 'px';
    }
    setOption(option) {
        this._tooltipOptions = { ...this._tooltipOptions, ...option };
    }
    getOption(option) {
        return this._tooltipOptions[option];
    }
    getTarget(el) {
        return hasClass(el, 'p-inputwrapper') ? findSingle(el, 'input') : el;
    }
    preAlign(position) {
        this.container.style.left = -999 + 'px';
        this.container.style.top = -999 + 'px';
        this.container.className = this.cn(this.cx('root'), this.ptm('root')?.class, 'p-tooltip-' + position, this.getOption('tooltipStyleClass'));
    }
    isOutOfBounds() {
        let offset = this.container.getBoundingClientRect();
        let targetTop = offset.top;
        let targetLeft = offset.left;
        let width = getOuterWidth(this.container);
        let height = getOuterHeight(this.container);
        let viewport = getViewport();
        return targetLeft + width > viewport.width || targetLeft < 0 || targetTop < 0 || targetTop + height > viewport.height;
    }
    onWindowResize(e) {
        this.hide();
    }
    bindDocumentResizeListener() {
        this.zone.runOutsideAngular(() => {
            this.resizeListener = this.onWindowResize.bind(this);
            window.addEventListener('resize', this.resizeListener);
        });
    }
    unbindDocumentResizeListener() {
        if (this.resizeListener) {
            window.removeEventListener('resize', this.resizeListener);
            this.resizeListener = null;
        }
    }
    bindScrollListener() {
        if (!this.scrollHandler) {
            this.scrollHandler = new ConnectedOverlayScrollHandler(this.el.nativeElement, () => {
                if (this.container) {
                    this.hide();
                }
            });
        }
        this.scrollHandler.bindScrollListener();
    }
    unbindScrollListener() {
        if (this.scrollHandler) {
            this.scrollHandler.unbindScrollListener();
        }
    }
    unbindEvents() {
        const tooltipEvent = this.getOption('tooltipEvent');
        if (tooltipEvent === 'hover' || tooltipEvent === 'both') {
            this.el.nativeElement.removeEventListener('mouseenter', this.mouseEnterListener);
            this.el.nativeElement.removeEventListener('mouseleave', this.mouseLeaveListener);
            this.el.nativeElement.removeEventListener('click', this.clickListener);
            // Touch support
            this.el.nativeElement.removeEventListener('touchstart', this.touchStartListener);
            this.el.nativeElement.removeEventListener('touchend', this.touchEndListener);
            this.unbindDocumentTouchListener();
        }
        if (tooltipEvent === 'focus' || tooltipEvent === 'both') {
            let target = this.el.nativeElement.querySelector('.p-component');
            if (!target) {
                target = this.getTarget(this.el.nativeElement);
            }
            target.removeEventListener('focus', this.focusListener);
            target.removeEventListener('blur', this.blurListener);
        }
        this.unbindDocumentResizeListener();
    }
    remove() {
        if (this.container && this.container.parentElement) {
            if (this.getOption('appendTo') === 'body')
                document.body.removeChild(this.container);
            else if (this.getOption('appendTo') === 'target')
                this.el.nativeElement.removeChild(this.container);
            else
                removeChild(this.getOption('appendTo'), this.container);
        }
        this.unbindDocumentResizeListener();
        this.unbindScrollListener();
        this.unbindContainerMouseleaveListener();
        this.unbindDocumentTouchListener();
        this.clearTimeouts();
        this.container = null;
        this.scrollHandler = null;
    }
    clearShowTimeout() {
        if (this.showTimeout) {
            clearTimeout(this.showTimeout);
            this.showTimeout = null;
        }
    }
    clearHideTimeout() {
        if (this.hideTimeout) {
            clearTimeout(this.hideTimeout);
            this.hideTimeout = null;
        }
    }
    clearTimeouts() {
        this.clearShowTimeout();
        this.clearHideTimeout();
    }
    onDestroy() {
        this.unbindEvents();
        if (this.container) {
            ZIndexUtils.clear(this.container);
        }
        this.remove();
        if (this.scrollHandler) {
            this.scrollHandler.destroy();
            this.scrollHandler = null;
        }
        if (this.documentEscapeListener) {
            this.documentEscapeListener();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: Tooltip, deps: [{ token: i0.NgZone }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.0", type: Tooltip, isStandalone: true, selector: "[pTooltip]", inputs: { tooltipPosition: { classPropertyName: "tooltipPosition", publicName: "tooltipPosition", isSignal: false, isRequired: false, transformFunction: null }, tooltipEvent: { classPropertyName: "tooltipEvent", publicName: "tooltipEvent", isSignal: false, isRequired: false, transformFunction: null }, positionStyle: { classPropertyName: "positionStyle", publicName: "positionStyle", isSignal: false, isRequired: false, transformFunction: null }, tooltipStyleClass: { classPropertyName: "tooltipStyleClass", publicName: "tooltipStyleClass", isSignal: false, isRequired: false, transformFunction: null }, tooltipZIndex: { classPropertyName: "tooltipZIndex", publicName: "tooltipZIndex", isSignal: false, isRequired: false, transformFunction: null }, escape: { classPropertyName: "escape", publicName: "escape", isSignal: false, isRequired: false, transformFunction: booleanAttribute }, showDelay: { classPropertyName: "showDelay", publicName: "showDelay", isSignal: false, isRequired: false, transformFunction: numberAttribute }, hideDelay: { classPropertyName: "hideDelay", publicName: "hideDelay", isSignal: false, isRequired: false, transformFunction: numberAttribute }, life: { classPropertyName: "life", publicName: "life", isSignal: false, isRequired: false, transformFunction: numberAttribute }, positionTop: { classPropertyName: "positionTop", publicName: "positionTop", isSignal: false, isRequired: false, transformFunction: numberAttribute }, positionLeft: { classPropertyName: "positionLeft", publicName: "positionLeft", isSignal: false, isRequired: false, transformFunction: numberAttribute }, autoHide: { classPropertyName: "autoHide", publicName: "autoHide", isSignal: false, isRequired: false, transformFunction: booleanAttribute }, fitContent: { classPropertyName: "fitContent", publicName: "fitContent", isSignal: false, isRequired: false, transformFunction: booleanAttribute }, hideOnEscape: { classPropertyName: "hideOnEscape", publicName: "hideOnEscape", isSignal: false, isRequired: false, transformFunction: booleanAttribute }, showOnEllipsis: { classPropertyName: "showOnEllipsis", publicName: "showOnEllipsis", isSignal: false, isRequired: false, transformFunction: booleanAttribute }, content: { classPropertyName: "content", publicName: "pTooltip", isSignal: false, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "tooltipDisabled", isSignal: false, isRequired: false, transformFunction: null }, tooltipOptions: { classPropertyName: "tooltipOptions", publicName: "tooltipOptions", isSignal: false, isRequired: false, transformFunction: null }, appendTo: { classPropertyName: "appendTo", publicName: "appendTo", isSignal: true, isRequired: false, transformFunction: null }, ptTooltip: { classPropertyName: "ptTooltip", publicName: "ptTooltip", isSignal: true, isRequired: false, transformFunction: null }, pTooltipPT: { classPropertyName: "pTooltipPT", publicName: "pTooltipPT", isSignal: true, isRequired: false, transformFunction: null }, pTooltipUnstyled: { classPropertyName: "pTooltipUnstyled", publicName: "pTooltipUnstyled", isSignal: true, isRequired: false, transformFunction: null } }, providers: [TooltipStyle, { provide: TOOLTIP_INSTANCE, useExisting: Tooltip }, { provide: PARENT_INSTANCE, useExisting: Tooltip }], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: Tooltip, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pTooltip]',
                    standalone: true,
                    providers: [TooltipStyle, { provide: TOOLTIP_INSTANCE, useExisting: Tooltip }, { provide: PARENT_INSTANCE, useExisting: Tooltip }]
                }]
        }], ctorParameters: () => [{ type: i0.NgZone }, { type: i0.ViewContainerRef }], propDecorators: { tooltipPosition: [{
                type: Input
            }], tooltipEvent: [{
                type: Input
            }], positionStyle: [{
                type: Input
            }], tooltipStyleClass: [{
                type: Input
            }], tooltipZIndex: [{
                type: Input
            }], escape: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], showDelay: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], hideDelay: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], life: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], positionTop: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], positionLeft: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], autoHide: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], fitContent: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], hideOnEscape: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], showOnEllipsis: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], content: [{
                type: Input,
                args: ['pTooltip']
            }], disabled: [{
                type: Input,
                args: ['tooltipDisabled']
            }], tooltipOptions: [{
                type: Input
            }], appendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "appendTo", required: false }] }], ptTooltip: [{ type: i0.Input, args: [{ isSignal: true, alias: "ptTooltip", required: false }] }], pTooltipPT: [{ type: i0.Input, args: [{ isSignal: true, alias: "pTooltipPT", required: false }] }], pTooltipUnstyled: [{ type: i0.Input, args: [{ isSignal: true, alias: "pTooltipUnstyled", required: false }] }] } });
class TooltipModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: TooltipModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.0", ngImport: i0, type: TooltipModule, imports: [Tooltip, BindModule], exports: [Tooltip, BindModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: TooltipModule, imports: [BindModule, BindModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: TooltipModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [Tooltip, BindModule],
                    exports: [Tooltip, BindModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Tooltip, TooltipClasses, TooltipModule, TooltipStyle };
//# sourceMappingURL=primeng-tooltip.mjs.map
