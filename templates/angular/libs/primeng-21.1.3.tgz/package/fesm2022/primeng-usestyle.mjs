import { DOCUMENT } from '@angular/common';
import * as i0 from '@angular/core';
import { inject, Injectable } from '@angular/core';
import { setAttribute, setAttributes } from '@primeuix/utils';

let _id = 0;
class UseStyle {
    document = inject(DOCUMENT);
    use(css, options = {}) {
        let isLoaded = false;
        let cssRef = css;
        let styleRef = null;
        const { immediate = true, manual = false, name = `style_${++_id}`, id = undefined, media = undefined, nonce = undefined, first = false, props = {} } = options;
        if (!this.document)
            return;
        styleRef = (this.document.querySelector(`style[data-primeng-style-id="${name}"]`) || (id && this.document.getElementById(id)) || this.document.createElement('style'));
        if (styleRef) {
            if (!styleRef.isConnected) {
                cssRef = css;
                const HEAD = this.document.head;
                setAttribute(styleRef, 'nonce', nonce);
                first && HEAD.firstChild ? HEAD.insertBefore(styleRef, HEAD.firstChild) : HEAD.appendChild(styleRef);
                setAttributes(styleRef, {
                    type: 'text/css',
                    media,
                    nonce,
                    'data-primeng-style-id': name
                });
            }
            if (styleRef.textContent !== cssRef) {
                styleRef.textContent = cssRef;
            }
        }
        return {
            id,
            name,
            el: styleRef,
            css: cssRef
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: UseStyle, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: UseStyle, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.0", ngImport: i0, type: UseStyle, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { UseStyle };
//# sourceMappingURL=primeng-usestyle.mjs.map
