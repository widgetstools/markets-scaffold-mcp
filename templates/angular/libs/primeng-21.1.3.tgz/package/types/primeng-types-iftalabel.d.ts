import { PassThrough, PassThroughOption } from 'primeng/api';

/**
 * Custom pass-through(pt) options.
 * @template I Type of instance.
 *
 * @see {@link IftaLabel.pt}
 * @group Interface
 */
interface IftaLabelPassThroughOptions<I = unknown> {
    /**
     * Used to pass attributes to the host's DOM element.
     */
    host?: PassThroughOption<HTMLElement, I>;
    /**
     * Used to pass attributes to the root's DOM element.
     */
    root?: PassThroughOption<HTMLSpanElement, I>;
}
/**
 * Custom passthrough attributes for each DOM elements
 * @group Interface
 */
type IftaLabelPassThrough<I = unknown> = PassThrough<I, IftaLabelPassThroughOptions<I>>;

export type { IftaLabelPassThrough, IftaLabelPassThroughOptions };
