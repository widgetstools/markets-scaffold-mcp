import * as i0 from '@angular/core';
import { ElementRef } from '@angular/core';
import { BaseComponent } from 'primeng/basecomponent';

/**
 * AutoFocus manages focus on focusable element on load.
 * @group Components
 */
declare class AutoFocus extends BaseComponent {
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus: boolean;
    focused: boolean;
    platformId: Object;
    document: Document;
    host: ElementRef;
    onAfterContentChecked(): void;
    onAfterViewChecked(): void;
    autoFocus(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AutoFocus, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AutoFocus, "[pAutoFocus]", never, { "autofocus": { "alias": "pAutoFocus"; "required": false; }; }, {}, never, never, true, never>;
}
declare class AutoFocusModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AutoFocusModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AutoFocusModule, never, [typeof AutoFocus], [typeof AutoFocus]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AutoFocusModule>;
}

export { AutoFocus, AutoFocusModule };
