import { PassThrough, PassThroughOption } from 'primeng/api';

/**
 * Custom pass-through(pt) options.
 * @template I Type of instance.
 *
 * @see {@link IconField.pt}
 * @group Interface
 */
interface IconFieldPassThroughOptions<I = unknown> {
    /**
     * Used to pass attributes to the host's DOM element.
     */
    host?: PassThroughOption<HTMLElement, I>;
    /**
     * Used to pass attributes to the root's DOM element.
     */
    root?: PassThroughOption<HTMLSpanElement, I>;
}
/**
 * Custom passthrough attributes for each DOM elements
 * @group Interface
 */
type IconFieldPassThrough<I = unknown> = PassThrough<I, IconFieldPassThroughOptions<I>>;

export type { IconFieldPassThrough, IconFieldPassThroughOptions };
