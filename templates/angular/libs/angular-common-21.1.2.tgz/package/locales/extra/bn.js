/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */
// THIS CODE IS GENERATED - DO NOT MODIFY.
const u = undefined;
export default [[["ভোর", "সকাল", "দুপুর", "বিকাল", "সন্ধ্যা", "রাত্রি"], u, ["ভোরবেলায়", "সকালবেলায়", "দুপুরবেলায়", "বিকাল", "সন্ধ্যাবেলায়", "রাত্রিবেলায়"]], [["ভোর", "সকাল", "দুপুর", "বিকাল", "সন্ধ্যা", "রাত্রি"], u, u], [["04:00", "06:00"], ["06:00", "12:00"], ["12:00", "16:00"], ["16:00", "18:00"], ["18:00", "20:00"], ["20:00", "04:00"]]];
//# sourceMappingURL=bn.js.map