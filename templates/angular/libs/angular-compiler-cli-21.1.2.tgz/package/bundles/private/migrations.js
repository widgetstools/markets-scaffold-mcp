
      import {createRequire as __cjsCompatRequire} from 'module';
      const require = __cjsCompatRequire(import.meta.url);
    
import {
  DiagnosticCategoryLabel,
  NgCompiler
} from "../chunk-5W3ZRJ6O.js";
import {
  CompilationMode,
  DtsMetadataReader,
  DynamicValue,
  FatalDiagnosticError,
  ImportManager,
  PartialEvaluator,
  PotentialImportKind,
  PotentialImportMode,
  Reference,
  ReferenceEmitKind,
  ReferenceEmitter,
  StaticInterpreter,
  SymbolKind,
  TypeScriptReflectionHost,
  createForwardRefResolver,
  extractDecoratorQueryMetadata,
  extractTemplate,
  findAngularDecorator,
  getAngularDecorators,
  getRootDirs,
  isShim,
  parseDecoratorInputTransformFunction,
  queryDecoratorNames,
  reflectObjectLiteral,
  unwrapExpression
} from "../chunk-GBKWMNM6.js";
import "../chunk-FROPOOFC.js";
import {
  getFileSystem,
  isLocalRelativePath
} from "../chunk-CEBE44Q5.js";
import {
  NodeJSFileSystem
} from "../chunk-XYYEESKY.js";
import "../chunk-G7GFT6BU.js";
export {
  CompilationMode,
  DiagnosticCategoryLabel,
  DtsMetadataReader,
  DynamicValue,
  FatalDiagnosticError,
  ImportManager,
  NgCompiler,
  NodeJSFileSystem,
  PartialEvaluator,
  PotentialImportKind,
  PotentialImportMode,
  Reference,
  ReferenceEmitKind,
  ReferenceEmitter,
  StaticInterpreter,
  SymbolKind,
  TypeScriptReflectionHost,
  createForwardRefResolver,
  extractDecoratorQueryMetadata,
  extractTemplate,
  findAngularDecorator,
  getAngularDecorators,
  getFileSystem,
  getRootDirs,
  isLocalRelativePath,
  isShim,
  parseDecoratorInputTransformFunction,
  queryDecoratorNames,
  reflectObjectLiteral,
  unwrapExpression
};
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */
